package com.company;

public class ExitCommand {

    public String execute(){
        return "Exit";
    }
}
