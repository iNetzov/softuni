package com.company;

public class Point2D {
    private int pointX;
    private int pointY;

    public Point2D(int pointX, int pointY) {
        this.pointX = pointX;
        this.pointY = pointY;
    }

    public int getPointX() {
        return pointX;
    }



    public int getPointY() {
        return pointY;
    }


}
