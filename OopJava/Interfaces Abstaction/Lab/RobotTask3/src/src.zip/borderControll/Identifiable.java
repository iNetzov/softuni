package borderControll;

public interface Identifiable {

    String getId();
}
