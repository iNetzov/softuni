package borderControll;

public class Robot extends BaseId{

    private String model;

    public Robot(String id, String model) {
        super(id);
        this.model = model;
    }

    public String getModel() {
        return model;
    }
}
